var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./RatingControl/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./RatingControl/index.ts":
/*!********************************!*\
  !*** ./RatingControl/index.ts ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar RatingControl =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function RatingControl() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  RatingControl.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._ratingDrpProperty = context.parameters.ratingDrpProperty.raw != \"\" ? context.parameters.ratingDrpProperty.raw.trim() : \"fas fa-star\";\n    this._ratingValueProperty = context.parameters.ratingValueProperty.raw != 0 ? context.parameters.ratingValueProperty.raw : 0;\n    this._ratingTotalNumberProperty = context.parameters.ratingTotalNumberProperty.raw != 0 ? context.parameters.ratingTotalNumberProperty.raw : 5;\n    this._ratingUnselectedColor = context.parameters.ratingUnselectedColorProperty.raw != \"\" ? context.parameters.ratingUnselectedColorProperty.raw.trim() : \"#bbcefb\";\n    this._ratingSelectedColor = context.parameters.ratingSelectedColorProperty.raw != \"\" ? context.parameters.ratingSelectedColorProperty.raw.trim() : \"#007bff\"; //Select Span \n\n    this._container = document.createElement(\"div\");\n    this._div = document.createElement(\"div\");\n    this._fontAwesomeCss = document.createElement(\"link\");\n    this._fontAwesomeCss.rel = \"stylesheet\";\n\n    this._fontAwesomeCss.setAttribute(\"href\", \"https://use.fontawesome.com/releases/v5.8.2/css/all.css\");\n\n    for (var _ratingElement = 1; _ratingElement <= this._ratingTotalNumberProperty; _ratingElement++) {\n      var ratingIdValue = this._ratingDrpProperty.replace(\" \", \"\") + \"_\" + _ratingElement;\n\n      var classImage = this._ratingDrpProperty + \" fa-3x margin-right \";\n      this._span = document.createElement(\"span\");\n\n      this._span.setAttribute(\"value\", ratingIdValue);\n\n      this._span.id = ratingIdValue;\n      this._span.className = classImage;\n      this._span.style.color = _ratingElement <= this._ratingValueProperty ? this._ratingSelectedColor : this._ratingUnselectedColor;\n\n      this._span.addEventListener(\"mouseover\", this.onHover.bind(this, _ratingElement));\n\n      this._div.appendChild(this._span);\n    }\n\n    this._labelRating = document.createElement(\"label\");\n    this._labelRating.id = \"labelRating\";\n    this._labelRating.className = \"label-fontsize\";\n\n    this._container.appendChild(this._fontAwesomeCss);\n\n    this._div.appendChild(this._labelRating);\n\n    this._container.appendChild(this._div);\n\n    container.appendChild(this._container);\n  };\n\n  RatingControl.prototype.onHover = function (value) {\n    this._ratingValueProperty = value;\n\n    this._notifyOutputChanged();\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  RatingControl.prototype.updateView = function (context) {\n    // Add code to update control view\n    this._ratingValueProperty = context.parameters.ratingValueProperty.raw != 0 ? context.parameters.ratingValueProperty.raw : 0;\n    this._context = context;\n    this._labelRating.innerHTML = this._ratingValueProperty.toString();\n\n    for (var _ratingElement = 1; _ratingElement <= this._ratingTotalNumberProperty; _ratingElement++) {\n      var _idValue = this._ratingDrpProperty.replace(\" \", \"\") + \"_\" + _ratingElement;\n\n      var _ratingelement = document.getElementById(_idValue);\n\n      _ratingelement.style.color = _ratingElement <= this._ratingValueProperty ? this._ratingSelectedColor : this._ratingUnselectedColor;\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  RatingControl.prototype.getOutputs = function () {\n    return {\n      ratingValueProperty: this._ratingValueProperty\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  RatingControl.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return RatingControl;\n}();\n\nexports.RatingControl = RatingControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./RatingControl/index.ts?");

/***/ })

/******/ });
var XRMControls = XRMControls || {};
XRMControls.RatingControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.RatingControl;
pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;